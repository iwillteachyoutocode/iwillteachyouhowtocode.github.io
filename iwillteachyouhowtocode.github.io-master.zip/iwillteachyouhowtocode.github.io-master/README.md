<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>LEARN TO CODE</title>
    </head>
    <body>
    
<h1>How to  code HTML</h1>
<ul>


<li>  <a href="#p-tag">     paragraph tags  </a>     </li>
  <li> <a href="#h-tag">      Header tags </a>  </li>
<li>  <a href="start">   The start of a webpage  </a>      </li>
  
  </ul>
<h2 id="p-tag" > paragraph tags
    
    
    
     
</h2><p>  There is the h1-6 tag 1 being the largest and 6 being the smallest. the other main writing tag is the p tag which stands for paragraph.
    <br>    You would write a paragraph tag  like this: <br> 

    
    
</p>

<img src="https://ka-perseus-images.s3.amazonaws.com/2b914caea7fdf9df8ff30e4780096d38624cab4f.png">  
        <h2 id ="h-tag">Header tags </h2>
<p>a header tag would look like this. the 1 can be substitued for any number 1-6</p>

<img   src="https://www.raybriant.com/wp-content/uploads/2011/09/heading-tags.gif">
        <h2 id="start"> The start of a webpage</h2>

<p> there is a certain few lines of code needed to create a website</p>

<img src="https://ka-perseus-images.s3.amazonaws.com/a88dceb91dbddc6f1c031bf92bedb90afca3ff05.png">


<p> you need all of those tags, except the p, and h1 tag. all your lines of code go in the body tag. </p>






  </body>
</html>

